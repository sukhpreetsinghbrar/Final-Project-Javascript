const from_curr = document.getElementById('from_currency');
const from_amt = document.getElementById('from_ammount');
const to_curr = document.getElementById('to_currency');
const to_amt = document.getElementById('to_ammount');
const rate_curr = document.getElementById('rate');
const exchange = document.getElementById('exchange');
 
from_curr.addEventListener('change', calculate);
from_amt.addEventListener('input', calculate);
to_curr.addEventListener('change', calculate);
to_amt.addEventListener('input', calculate);
 
exchange.addEventListener('click', () => {
	const temp = from_curr.value;
	from_curr.value = to_curr.value;
	to_curr.value = temp;
	calculate();
});

// restrict the ascii values of keys// coded by Jaspreet
function isNumberKey(txt,evt)
{
		   
   // restrict length 5
   if (txt.value.length >= 5) {
		return false;
	}
	
	// only allow digits and decimal ascii decimal values
	var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
			return false;

	return true;
       
}
 
function calculate() {
	const from_currency = from_curr.value;
	const to_currency = to_curr.value;
	
	fetch(`https://api.exchangerate-api.com/v4/latest/${from_currency}`)
		.then(res => res.json())
		.then(res => {
		const rate = res.rates[to_currency];
		rate_curr.innerText = `1 ${from_currency} = ${rate} ${to_currency}`
		to_amt.value = (from_amt.value * rate).toFixed(2);
	})
}
 
calculate();
